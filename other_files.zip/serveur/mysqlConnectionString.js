var mysqlConnectionString = {

    connection : {
        dev:{
            host: "localhost",
            user:"root",
            password:"",
            database:"justice_bd"
        }
    }
};

module.exports.mysqlConnectionString = mysqlConnectionString;