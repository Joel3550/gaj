/**
 * Created by AdminWACo on 09/08/2016.
 */
//var request = require('request');
//var express = require('express');
//var router = express.Router();
//
//router.get('/printMinute', function(res, req, next){
//
//
//        var data = {
//            template : {'shortid':'B1Gd6rrF'},
//            data : {
//                'nom' : 'ossé',
//                'prenom': 'joel'
//            }
//        }
//        var options = {
//            uri : 'http://localhost:1337/api/report',
//            method : 'POST',
//            json : data
//        }
//        request(options).pipe(res);
//
//});
//
//module.exports = router;